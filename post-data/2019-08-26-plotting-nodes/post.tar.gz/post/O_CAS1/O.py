#! /usr/bin/env python

import sys,os
from pyscf import scf,gto,lib,mcscf
import pyscf.lib.chkfile
import numpy as np
import pyscf2qwalk as qw

workdir = os.path.dirname(os.path.realpath(__file__))
basfile = os.path.join(workdir,'my_basis')
#ecpfile = os.path.join(workdir,'my_ecp')

#~~~~Build the molecule~~~~
mol = gto.Mole()
mol.atom = '''O 0.0 0.0 0.0 '''
mol.basis = {'O': gto.load(basfile,'O')}
#mol.basis = {'O':'bfd-vtz'}
#mol.basis = {'O': gto.basis.parse('''
#''')}
mol.symmetry = 'D2h'
mol.spin = 2	# 2S
mol.charge = 0
#mol.ecp = {'O': gto.load(ecpfile,'O')}
#mol.ecp={'O':'bfd'}
mol.ecp={'O': gto.basis.parse_ecp('''
O nelec 2
O ul
1 12.30997 6.000000
3 14.76962 73.85984
2 13.71419 -47.87600
O S
2 13.65512 85.86406
''')}
mol.build()

#~~~Run HF on molecule~~~~
hf = scf.ROHF(mol) #.apply(scf.addons.remove_linear_dep_)
hf.irrep_nelec = {
'Ag' : (1,1),   # s    
'B3u': (1,1),   # x    1
'B2u': (1,0),   # y   -1
'B1g': (0,0),   # xy  -2
'B1u': (1,0),   # z    0
'B2g': (0,0),   # xz   1
'B3g': (0,0),   # yz  -1
'Au' : (0,0)    # xyz  
}
hf.verbose=4
hf.max_cycle=150
#dm=hf.init_guess_by_chkfile('../guess/O.chkfile')
#hf.chkfile='O.chkfile'
#en=hf.kernel(dm)
en=hf.kernel()
#hf.mulliken_pop()


###~~~ Run CASSCF ~~~
mc = mcscf.CASSCF(hf, 19, 6)   #22
mc.kernel()[0]
mc.verbose = 4
mc.analyze()



#kpts=[]
#title="N"
#from PyscfToQmcpack import savetoqmcpack
#savetoqmcpack(mol,mc,title=title,kpts=kpts)

### ~~~~ Following QWalk converter can't convert basis with H or greater functions!
qw.print_qwalk(mol,mc,method='mcscf',tol=1e-4,basename='qwalk')

